<? include("top.php"); ?>
	<div class="container">
		<div class="list-group">
			<a href="checkout.php" class="list-group-item">Check Out Books</a>
			<a href="addbook.php" class="list-group-item">Add a Book</a>
			<a href="books.php" class="list-group-item">Manage Books</a>
			<a href="patrons.php" class="list-group-item">Manage Patrons</a>
		</div>
	</div>
<? include("bottom.php"); ?>